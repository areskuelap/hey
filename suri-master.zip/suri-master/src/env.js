module.exports = {
  js: process.env.SURI_JS === '1',
}
